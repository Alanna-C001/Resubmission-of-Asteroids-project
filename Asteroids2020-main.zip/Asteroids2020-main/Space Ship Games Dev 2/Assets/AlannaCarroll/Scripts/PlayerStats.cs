﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStats : MonoBehaviour
{

    // please use this script if there is not health variable on the player (spaceship) 
    //I couldn't find any health variables in the other codes so I made a simple script for it!
    public float health = 100f;
    public float speed = 5f;
}
